const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
require('dotenv').config();

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({ secret: 'secret', resave: false, saveUninitialized: true }));

app.set('view engine', 'ejs');

// Routes
const authRoutes = require('./routes/auth');
const gajiRoutes = require('./routes/gaji');

app.use('/', authRoutes);
app.use('/gaji', isLogin, gajiRoutes);

app.get('/', (req, res) => {
  res.redirect('/login');
});

function isLogin(req, res, next) {
  if (req.session.loggedIn) return next();
  res.redirect('/login');
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server berjalan di http://localhost:${PORT}`));
