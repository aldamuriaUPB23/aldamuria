const db = require('../config/db');
const bcrypt = require('bcrypt');

exports.loginPage = (req, res) => {
  res.render('auth/login');
};

exports.login = (req, res) => {
  const { username, password } = req.body;
  db.query('SELECT * FROM users WHERE username = ?', [username], async (err, result) => {
    if (err) throw err;
    if (result.length > 0 && await bcrypt.compare(password, result[0].password)) {
      req.session.loggedIn = true;
      res.redirect('/gaji');
    } else {
      res.send('Login gagal. Coba lagi.');
    }
  });
};
