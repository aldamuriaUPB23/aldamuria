const db = require('../config/db');

exports.index = (req, res) => {
  const search = req.query.search || '';
  db.query('SELECT * FROM gaji WHERE nama LIKE ?', [`%${search}%`], (err, rows) => {
    if (err) throw err;
    res.render('gaji/index', { gaji: rows, search });
  });
};

exports.addPage = (req, res) => res.render('gaji/add', { data: null });


exports.save = (req, res) => {
  const { nama, jabatan, gaji } = req.body;
  db.query('INSERT INTO gaji SET ?', { nama, jabatan, gaji }, () => res.redirect('/gaji'));
};

exports.editPage = (req, res) => {
  db.query('SELECT * FROM gaji WHERE id = ?', [req.params.id], (err, rows) => {
    res.render('gaji/edit', { data: rows[0] });
  });
};

exports.update = (req, res) => {
  const { nama, jabatan, gaji } = req.body;
  db.query('UPDATE gaji SET ? WHERE id = ?', [{ nama, jabatan, gaji }, req.params.id], () => res.redirect('/gaji'));
};

exports.delete = (req, res) => {
  db.query('DELETE FROM gaji WHERE id = ?', [req.params.id], () => res.redirect('/gaji'));
};
