const express = require('express');
const router = express.Router();
const gaji = require('../controllers/gajiController');

router.get('/', gaji.index);
router.get('/add', gaji.addPage);
router.post('/add', gaji.save);
router.get('/edit/:id', gaji.editPage);
router.post('/edit/:id', gaji.update);
router.get('/delete/:id', gaji.delete);

module.exports = router;
