const express = require('express');
const router = express.Router();
const auth = require('../controllers/authController');

router.get('/login', auth.loginPage);
router.post('/login', auth.login);

module.exports = router;
router.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    res.redirect('/login');
  });
});
